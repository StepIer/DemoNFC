package com.pro100svitlo.creditCardNfcReader.enums;

public enum TagValueTypeEnum {
	BINARY, NUMERIC, TEXT, MIXED, DOL, TEMPLATE
}
